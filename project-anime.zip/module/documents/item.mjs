import { rollAttack, rollSkill, postConsumableCard } from "../helpers/dice.mjs";

/**
 * Extends the base Item with Project: Anime behaviour: roll data and a
 * type-aware `roll()` (weapons/shields attack, skills resolve, others post a card).
 */
export class ProjectAnimeItem extends Item {
  /** @override */
  getRollData() {
    const data = { ...this.system };
    if (this.actor) data.actor = this.actor.getRollData();
    return data;
  }

  /**
   * Roll or use this item.
   * @param {object} [options]
   * @param {Event}  [options.event]  Originating event (Shift skips roll dialogs).
   */
  async roll(options = {}) {
    if (this.actor) {
      if (this.type === "weapon" || this.type === "shield") return rollAttack(this.actor, this, options);
      if (this.type === "skill") return rollSkill(this.actor, this, options);
      if (this.type === "consumable") return postConsumableCard(this.actor, this);
    }
    return this.#postDescriptionCard();
  }

  /** Post a simple identity + description card to chat. */
  async #postDescriptionCard() {
    const speaker = ChatMessage.getSpeaker({ actor: this.actor });
    const typeLabel = game.i18n.localize(`TYPES.Item.${this.type}`);
    const TE = foundry.applications?.ux?.TextEditor?.implementation ?? globalThis.TextEditor;
    const raw = this.system.description ?? "";
    const enriched = raw && String(raw).trim()
      ? await TE.enrichHTML(String(raw), { secrets: false, rollData: this.getRollData() })
      : "";
    const iconHTML = this.img ? `<img class="card-icon" src="${this.img}" alt="" />` : "";
    const descHTML = enriched ? `<div class="card-desc">${enriched}</div>` : "";
    const content = `<div class="project-anime chat-card">
      <header class="card-header">
        ${iconHTML}
        <div class="card-titles">
          <h3 class="card-title">${this.name}</h3>
          <span class="card-type">${typeLabel}</span>
        </div>
      </header>
      ${descHTML}
    </div>`;
    return ChatMessage.create({ speaker, content });
  }
}
